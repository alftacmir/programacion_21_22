package Unidad4.Tacón_Miranda_Alfonso_U4_T1_Entrega;

public enum Estancias {
    SALON,
    COCINA,
    BANNO,
    DORMITORIO,
    TERRAZA,
    VESTIBULO,
    COMEDOR,
    BALCON
}
