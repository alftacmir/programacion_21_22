package Unidad5.Tacón_Miranda_Alfonso_U4_U5_Examen;

public interface Callejera {
    public void amo_a_escucha();
}
