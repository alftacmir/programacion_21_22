package Unidad5.Tacón_Miranda_Alfonso_EntregableU4U5;

public interface Reproducible {

    public void play();
    public void pause();
    public void stop();
}
